package testing;

import Predictions.Concurrent_Callable;
import Predictions.Concurrent_Runnable;
import Predictions.Predictor;

import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Predictor p = new Predictor();
        Concurrent_Runnable r = new Concurrent_Runnable();
        Concurrent_Callable c = new Concurrent_Callable();
        p.mitty();
        r.mitty();
        c.mitty();
        org.openjdk.jmh.Main.main(args);
    }
}
