package Predictions;

import org.openjdk.jmh.annotations.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import static Predictions.Gradient_descent.gradientDescent;
import static Predictions.Predictor.*;

public class Concurrent_Runnable {

    public static double[][] gradientDescent(double[][] grades, double[] finalGrades, double[][] theta, double alpha, int iterations, boolean updates) {
        for (int iteration = 0; iteration < iterations; iteration++) {

            ThreadPoolExecutor executor;
            executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(20);
            Runnable_task M = new Runnable_task();
            executor.submit(M);
            executor.shutdown();

        }
        return theta;
    }


    @Benchmark
    @BenchmarkMode(Mode.AverageTime)
    @Warmup(iterations = 4)
    @Measurement(iterations = 4)
    @OutputTimeUnit(TimeUnit.MILLISECONDS)
    @Timeout(time = 30, timeUnit = TimeUnit.SECONDS)
    @Fork(2)
    public void mitty() throws FileNotFoundException {
        File f = new File("student-mat.csv");
        double[][] data = shuffleData(parseData(f));

        // useful values
        int setSize = data.length;
        int trainingSize = (int) (Math.round(setSize * 0.7));
        int features = data[0].length;

        // partition data into sets
        double[][] trainingSet = getInputsAndBias(data, 0, trainingSize);
        double[] trainingLabels = getOutputs(data, 0, trainingSize);
        double[][] testSet = getInputsAndBias(data, trainingSize, setSize);
        double[] testLabels = getOutputs(data, trainingSize, setSize);

        // train data to find optimal theta
        double[][] theta = gradientDescent(trainingSet, trainingLabels, new double[features][1], 0.005, 5000, false);

        // display results of training
        double cost = cost(theta, testSet, testLabels);
        testTheta(testSet, testLabels, theta);
        System.out.println(cost);
    }
}

class Runnable_task implements Runnable{

    @Override
    public void run() {


        int[] gradients = new int[0];
        double[][] grades = new double[0][];
        for (int i = 0; i < grades.length; i++) {
            for (int j = 0; j < gradients.length; j++) {
                double[][] predictions = new double[0][];
                double[] finalGrades = new double[0];
                gradients[j] += (predictions[i][0] - finalGrades[i]) * grades[i][j];
            }
        }
        for (int j = 0; j < gradients.length; j++) {
            int alpha = 0;
            gradients[j] *= alpha / grades.length;
            int[][] theta = new int[0][];
            theta[j][0] -= gradients[j];
        }
        boolean updates = true;
        if (updates) {
            double[][] theta = new double[0][];
            double[] finalGrades = new double[0];
            System.out.println(cost(theta, grades, finalGrades));
        }

    }
}
