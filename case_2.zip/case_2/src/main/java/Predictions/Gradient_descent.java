package Predictions;

import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;

import static Predictions.Predictor.cost;
import static Predictions.Predictor.dotArrays;

public class Gradient_descent {


    public static double[][] gradientDescent(double[][] grades, double[] finalGrades, double[][] theta, double alpha, int iterations, boolean updates) {
        for (int iteration = 0; iteration < iterations; iteration++) {
            double[] gradients = new double[grades[0].length];
            double[][] predictions = dotArrays(grades, theta);
            for (int i = 0; i < grades.length; i++) {
                for (int j = 0; j < gradients.length; j++) {
                    gradients[j] += (predictions[i][0] - finalGrades[i]) * grades[i][j];
                }
            }
            for (int j = 0; j < gradients.length; j++) {
                gradients[j] *= alpha / grades.length;
                theta[j][0] -= gradients[j];
            }
            if (updates) {
                System.out.println(cost(theta, grades, finalGrades));
            }
        }
        return theta;
    }
}
