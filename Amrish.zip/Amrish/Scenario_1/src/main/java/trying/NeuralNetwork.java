package trying;

import org.openjdk.jmh.annotations.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;


class Callable_Implementation implements Callable <String> {
    static int[][] dataa;

    int[] grp = new int[467];
    double lc = 0.4;
    double[] op1;
    double[] op2;
    double[] op3;

    @Override
    public String call() throws Exception {
        return (String) callable();
    }


    private Object callable() {

        for (int it = 0; it < 1000; it++) {

            for (int i = 0; i < 467; i++) {
                double op1Sum = 0;
                double op2Sum = 0;
                double op3Sum = 0;
                double one = 0;
                for (int j = 0; j < 14; j++) {
                    if (dataa[i][j] == 1) {
                        one++;
                    }
                    op1Sum += dataa[i][j] * op1[j];
                    op2Sum += dataa[i][j] * op2[j];
                    op3Sum += dataa[i][j] * op3[j];

                }

                op1Sum = Math.round(op1Sum * 1000.0) / 1000.0;
                op2Sum = Math.round(op2Sum * 1000.0) / 1000.0;
                op3Sum = Math.round(op3Sum * 1000.0) / 1000.0;

                System.out.println(op1Sum + " - " + op2Sum + " - " + op3Sum + "  are the equation 1 values for data set " + (i + 1));

                if (op1Sum >= op2Sum && op1Sum >= op3Sum) {
                    for (int k = 0; k < 14; k++) {
                        double temp = lc * ((dataa[i][k] / one) - op1[k]);

                        op1[k] += temp;
                        op1[k] = Math.round(op1[k] * 1000.0) / 1000.0;

                    }

                    grp[i] = 1;

                } else if (op2Sum >= op1Sum && op2Sum >= op3Sum) {
                    for (int k = 0; k < 14; k++) {
                        double temp = lc * ((dataa[i][k] / one) - op2[k]);

                        op2[k] += temp;
                        op2[k] = Math.round(op2[k] * 1000.0) / 1000.0;

                    }

                    grp[i] = 2;
                } else if (op3Sum >= op2Sum && op1Sum <= op3Sum) {
                    for (int k = 0; k < 14; k++) {
                        double temp = lc * ((dataa[i][k] / one) - op3[k]);

                        op3[k] += temp;
                        op3[k] = Math.round(op3[k] * 1000.0) / 1000.0;
                    }

                    grp[i] = 3;
                }

            }

            System.out.println("After " + it + " Iteration weights are :");
            for (int m = 0; m < 14; m++) {
                System.out.println(op1[m] + " ; " + op2[m] + " ; " + " = " + op3[m]);
            }

            System.out.println("\nAfter " + it + " Iteration grouping is:");
            for (int m = 0; m < 467; m++) {
                System.out.println("dataset " + (m + 1) + " belongs to Group: " + grp[m]);
            }


        }

        return null;
    }

}
