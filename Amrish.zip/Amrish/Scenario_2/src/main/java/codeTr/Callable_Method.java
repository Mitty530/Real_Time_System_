package codeTr;
import org.openjdk.jmh.annotations.*;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.*;

import static codeTr.BpDeepTest.indata;


public class Callable_Method {

    public void mitty() {
        BP bp1 = new BP(13, 13, 5);
        BpDeepTest p = new BpDeepTest();

        long startTime = System.currentTimeMillis();

        BpDeepTest.loadData("AirQualityUCI.data");
        p.pretreatment(indata);


        double[][] train_data = new double[p.data.size()][p.data.get(0).length - 1];
        int r = 0;
        while (r < p.data.size()) {
            double[] tem = p.data.get(r);
            for (int j = 0; j < tem.length - 1; j++) {
                train_data[r][j] = tem[j];
            }
            r++;
        }

        double[][] target = new double[p.data.size()][5];//
        r = 0;
        while (r < p.data.size()) {
            int t = (int) p.data.get(r)[13];
            switch (t) {
                case 1: {
                    target[r] = new double[]{1.0, 0.0, 0.0, 0.0, 0.0};
                    break;
                }
                case 2: {
                    target[r] = new double[]{0.0, 1.0, 0.0, 0.0, 0.0};
                    break;
                }
                case 3: {
                    target[r] = new double[]{0.0, 0.0, 1.0, 0.0, 0.0};
                    break;
                }
                case 4: {
                    target[r] = new double[]{0.0, 0.0, 0.0, 1.0, 0.0};
                    break;
                }
                case 5: {
                    target[r] = new double[]{0.0, 0.0, 0.0, 0.0, 1.0};
                    break;
                }
                default:
                    break;
            }
            r++;
        }




        for (int s = 0; s < 100; s++) {

            for (int i = 0; i < p.data.size(); i++) {
                bp1.train(train_data[i], target[i]);
            }

            int correct = 0;
            for (int j = 0; j < p.data.size(); j++) {
                double[] result = bp1.test(train_data[j]);
                double max = 0;
                int NO = 0;
                for (int i = 0; i < result.length; i++) {
                    if (result[i] >= max) {
                        max = result[i];
                        NO = i;
                    }

                }
                if (target[j][NO] == 1.0) {
                    correct++;
                }
                else if(s==9999)//Output the wrong result of the test after 10000 times of training
                    System.out.println("NS"+(s+1)+"After training,the first"+j+"No. test case prediction error--------------");
            }

            double b=(correct * 1.0 / p.data.size()) * 100;//Calculate the correct rate
            DecimalFormat df = new DecimalFormat( "0.00 ");//Set output accuracy
            System.out.println("NS " + (s+1) + " After training, the correct rate of detection using the training set is  ==" +df.format(b) + "%");
        }


        double[] x = new double[]{-200,883,-200,1.3,530,63,997,46,1102,617,13.7,68.2,1.0611};
        System.out.print("Use test cases" + Arrays.toString(x) + "   According to the calculation of the neural network, the estimated air quality is：");
        for(int i=0;i<x.length;i++)
            x[i]=x[i]/p.weigth[i];//Normalize the data

        double[] result = bp1.test(x);
        System.out.println(p.Show_air_quality(result));




        System.out.println("The running time of the program is：" + (System.currentTimeMillis() - startTime) * 1.0 / 1000 + " s");
    }



    /**
     * Calculate hidden errors.
     */


    @Benchmark
    @BenchmarkMode(Mode.AverageTime)
    @Warmup(iterations = 3)
    @Measurement(iterations = 3)
    @OutputTimeUnit(TimeUnit.MILLISECONDS)
    @Timeout(time=30, timeUnit = TimeUnit.SECONDS)
    @Fork(2)
    public void hiddenErr() {

        List<Future<String>> returedFutures = new ArrayList<>();
        ThreadPoolExecutor executor;
        executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(20);
        callable_task task = new callable_task();
        Future<String> future = executor.submit(task);
        returedFutures.add(future);
        executor.shutdown();
    }


    public void outputErr() {

        BP b = new BP(13, 13, 5);

        double errSum = 0;
        for (int idx = 1, len = b.optDelta.length; idx != len; ++idx) {
            double o = b.output[idx];
            b.optDelta[idx] = o * (1d - o) * (b.target[idx] - o);
            errSum += Math.abs(b.optDelta[idx]);
        }
        b.optErrSum = errSum;
    }

}

class callable_task implements Callable <String>{
    @Override
    public String call() throws Exception {
        return callable();
    }

    public String callable(){

        BP b = new BP(13, 13, 5);

        double errSum = 0;
        for (int j = 1, len = b.hidDelta.length; j != len; ++j) {
            double o = b.hidden[j];
            double sum = 0;
            for (int k = 1, len2 = b.optDelta.length; k != len2; ++k)
                sum += b.hidOptWeights[j][k] * b.optDelta[k];
            b.hidDelta[j] = o * (1d - o) * sum;
            errSum += Math.abs(b.hidDelta[j]);
        }
        b.hidErrSum = errSum;
        return null;
    }
}
