package codeTr;

import org.openjdk.jmh.annotations.*;

import java.util.concurrent.TimeUnit;

public class Mitty {

    @Benchmark
    @BenchmarkMode(Mode.AverageTime)
    @Warmup(iterations = 3)
    @Measurement(iterations = 3)
    @OutputTimeUnit(TimeUnit.MILLISECONDS)
    @Timeout(time=30, timeUnit = TimeUnit.SECONDS)
    @Fork(2)
    public void calculateDelta() {
        finding f = new finding();
        Implementing_Runnable_Method re = new Implementing_Runnable_Method();
        Callable_Method ca = new Callable_Method();


        re.hiddenErr();
        re.hiddenErr();
        ca.outputErr();
        ca.hiddenErr();
    }
}
