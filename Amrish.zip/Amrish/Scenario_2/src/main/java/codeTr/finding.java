package codeTr;

import org.openjdk.jmh.annotations.*;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import static codeTr.BpDeepTest.indata;

public class finding {


}

