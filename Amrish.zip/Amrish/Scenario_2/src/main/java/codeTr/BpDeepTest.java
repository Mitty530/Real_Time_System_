package codeTr;

import codeTr.BP;
import org.openjdk.jmh.annotations.*;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.TimeUnit;

public class BpDeepTest {

    public static Vector<String> indata = new Vector<>();  //
    public static Vector<double[]> data = new Vector<>();//

    static double[] max = new double[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    static double[] min = new double[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    static double[] weigth = new double[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};


    public static boolean loadData(String url) {
        try {
            Scanner in = new Scanner(new File(url));
            while (in.hasNextLine()) {
                String str = in.nextLine();
                indata.add(str);
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }


    public static void pretreatment(Vector<String> indata) {
        Vector<double[]> temdata = new Vector<>();

        int i = 1;
        String t;
        while (i < indata.size()) {
            double[] tem = new double[14];
            t = indata.get(i);
            String[] sourceStrArray = t.split(",", 16);

            for (int j = 0; j < 13; j++) {
                tem[j] = Double.parseDouble(sourceStrArray[j + 2]);
                if (tem[j] > max[j])
                    max[j] = tem[j];
                if (tem[j] < min[j])
                    min[j] = tem[j];
            }
            switch (sourceStrArray[15]) {
                case "Very High": {
                    tem[13] = 1;
                    break;
                }
                case "High": {
                    tem[13] = 2;
                    break;
                }
                case "Moderate": {
                    tem[13] = 3;
                    break;
                }
                case "Low": {
                    tem[13] = 4;
                    break;
                }
                case "Very low": {
                    tem[13] = 5;
                    break;
                }
                default:
                    break;

            }
            temdata.add(tem);
            i++;
        }

        for (int r = 0; r < max.length; r++) {
            weigth[r] = max[r] - min[r];
        }

        for (int r = 0; r < temdata.size(); r++) {
            double[] t1 = temdata.get(r);
            for (int j = 0; j < t1.length - 1; j++) {
                t1[j] = t1[j] / weigth[j];
            }

            data.add(t1);
        }

    }


    public static String Show_air_quality(double[] result) {
        String rt = "";
        int NO = 0;
        double max = 0;
        for (int i = 0; i < result.length; i++) {
            if (result[i] >= max) {
                max = result[i];
                NO = i;
            }

        }
        switch (NO) {
            case 0: {
                rt = "Very high";
                break;
            }
            case 1: {
                rt = "High";
                break;
            }
            case 2: {
                rt = "Moderate";
                break;
            }
            case 3: {
                rt = "Low";
                break;
            }
            case 4: {
                rt = "Very low";
                break;
            }
            default:
                break;
        }

        return rt;
    }

    public void test()
    // public static void main(String[] args) throws IOException
    {
        BP bp1 = new BP(13, 13, 5);
        BpDeepTest p = new BpDeepTest();

        long startTime = System.currentTimeMillis();

        BpDeepTest.loadData("AirQualityUCI.data");
        p.pretreatment(indata);


        double[][] train_data = new double[p.data.size()][p.data.get(0).length - 1];
        int r = 0;
        while (r < p.data.size()) {
            double[] tem = p.data.get(r);
            for (int j = 0; j < tem.length - 1; j++) {
                train_data[r][j] = tem[j];
            }
            r++;
        }

        double[][] target = new double[p.data.size()][5];//
        r = 0;
        while (r < p.data.size()) {
            int t = (int) p.data.get(r)[13];
            switch (t) {
                case 1: {
                    target[r] = new double[]{1.0, 0.0, 0.0, 0.0, 0.0};
                    break;
                }
                case 2: {
                    target[r] = new double[]{0.0, 1.0, 0.0, 0.0, 0.0};
                    break;
                }
                case 3: {
                    target[r] = new double[]{0.0, 0.0, 1.0, 0.0, 0.0};
                    break;
                }
                case 4: {
                    target[r] = new double[]{0.0, 0.0, 0.0, 1.0, 0.0};
                    break;
                }
                case 5: {
                    target[r] = new double[]{0.0, 0.0, 0.0, 0.0, 1.0};
                    break;
                }
                default:
                    break;
            }
            r++;
        }





        for (int s = 0; s < 100; s++) {

            for (int i = 0; i < p.data.size(); i++) {
                bp1.train(train_data[i], target[i]);
            }

            int correct = 0;
            for (int j = 0; j < p.data.size(); j++) {
                double[] result = bp1.test(train_data[j]);
                double max = 0;
                int NO = 0;
                for (int i = 0; i < result.length; i++) {
                    if (result[i] >= max) {
                        max = result[i];
                        NO = i;
                    }

                }
                if (target[j][NO] == 1.0) {
                    correct++;
                }
                else if(s==9999)//Output the wrong result of the test after 10000 times of training
                    System.out.println("NS"+(s+1)+"After training,the first"+j+"No. test case prediction error--------------");
            }

            double b=(correct * 1.0 / p.data.size()) * 100;//Calculate the correct rate
            DecimalFormat df = new DecimalFormat( "0.00 ");//Set output accuracy
            System.out.println("NS " + (s+1) + " After training, the correct rate of detection using the training set is  ==" +df.format(b) + "%");
        }


        double[] x = new double[]{-200,883,-200,1.3,530,63,997,46,1102,617,13.7,68.2,1.0611};
        System.out.print("Use test cases" + Arrays.toString(x) + "   According to the calculation of the neural network, the estimated air quality is：");
        for(int i=0;i<x.length;i++)
            x[i]=x[i]/p.weigth[i];//Normalize the data

        double[] result = bp1.test(x);
        System.out.println(p.Show_air_quality(result));




        System.out.println("The running time of the program is：" + (System.currentTimeMillis() - startTime) * 1.0 / 1000 + " s");
    }



    }
