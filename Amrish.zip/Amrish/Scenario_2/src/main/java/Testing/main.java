package Testing;

import java.io.IOException;

public class main {
    public static void main(String[] args) throws IOException {

        org.openjdk.jmh.Main.main(args);

    }
}
